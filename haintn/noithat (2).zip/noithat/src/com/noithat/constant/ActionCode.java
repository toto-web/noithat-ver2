package com.noithat.constant;

public class ActionCode {

}
